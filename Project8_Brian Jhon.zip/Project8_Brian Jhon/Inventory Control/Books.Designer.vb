﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBooks
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstBooks = New System.Windows.Forms.ListBox()
        Me.MainMenu1 = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBook = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBookAdd = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBookDelete = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBookUpdate = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDisplay = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDisplayAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDisplayFiction = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDisplayNonfiction = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuValues = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuValuesAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuValuesFiction = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuValuesNonfiction = New System.Windows.Forms.ToolStripMenuItem()
        Me.MainMenu1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lstBooks
        '
        Me.lstBooks.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstBooks.FormattingEnabled = True
        Me.lstBooks.ItemHeight = 14
        Me.lstBooks.Location = New System.Drawing.Point(12, 27)
        Me.lstBooks.Name = "lstBooks"
        Me.lstBooks.Size = New System.Drawing.Size(303, 186)
        Me.lstBooks.TabIndex = 0
        '
        'MainMenu1
        '
        Me.MainMenu1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuBook, Me.mnuDisplay, Me.mnuValues})
        Me.MainMenu1.Location = New System.Drawing.Point(0, 0)
        Me.MainMenu1.Name = "MainMenu1"
        Me.MainMenu1.Size = New System.Drawing.Size(332, 24)
        Me.MainMenu1.TabIndex = 1
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileSave, Me.mnuFileExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "File"
        '
        'mnuFileSave
        '
        Me.mnuFileSave.Name = "mnuFileSave"
        Me.mnuFileSave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnuFileSave.Size = New System.Drawing.Size(180, 22)
        Me.mnuFileSave.Text = "Save"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Q), System.Windows.Forms.Keys)
        Me.mnuFileExit.Size = New System.Drawing.Size(180, 22)
        Me.mnuFileExit.Text = "Exit"
        '
        'mnuBook
        '
        Me.mnuBook.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuBookAdd, Me.mnuBookDelete, Me.mnuBookUpdate})
        Me.mnuBook.Name = "mnuBook"
        Me.mnuBook.Size = New System.Drawing.Size(46, 20)
        Me.mnuBook.Text = "Book"
        '
        'mnuBookAdd
        '
        Me.mnuBookAdd.Name = "mnuBookAdd"
        Me.mnuBookAdd.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.mnuBookAdd.Size = New System.Drawing.Size(154, 22)
        Me.mnuBookAdd.Text = "Add"
        '
        'mnuBookDelete
        '
        Me.mnuBookDelete.Name = "mnuBookDelete"
        Me.mnuBookDelete.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.mnuBookDelete.Size = New System.Drawing.Size(154, 22)
        Me.mnuBookDelete.Text = "Delete"
        '
        'mnuBookUpdate
        '
        Me.mnuBookUpdate.Name = "mnuBookUpdate"
        Me.mnuBookUpdate.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.U), System.Windows.Forms.Keys)
        Me.mnuBookUpdate.Size = New System.Drawing.Size(154, 22)
        Me.mnuBookUpdate.Text = "Update"
        '
        'mnuDisplay
        '
        Me.mnuDisplay.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDisplayAll, Me.mnuDisplayFiction, Me.mnuDisplayNonfiction})
        Me.mnuDisplay.Name = "mnuDisplay"
        Me.mnuDisplay.Size = New System.Drawing.Size(57, 20)
        Me.mnuDisplay.Text = "Display"
        '
        'mnuDisplayAll
        '
        Me.mnuDisplayAll.Checked = True
        Me.mnuDisplayAll.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnuDisplayAll.Name = "mnuDisplayAll"
        Me.mnuDisplayAll.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.mnuDisplayAll.Size = New System.Drawing.Size(180, 22)
        Me.mnuDisplayAll.Text = "All"
        '
        'mnuDisplayFiction
        '
        Me.mnuDisplayFiction.Name = "mnuDisplayFiction"
        Me.mnuDisplayFiction.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.mnuDisplayFiction.Size = New System.Drawing.Size(180, 22)
        Me.mnuDisplayFiction.Text = "Fiction"
        '
        'mnuDisplayNonfiction
        '
        Me.mnuDisplayNonfiction.Name = "mnuDisplayNonfiction"
        Me.mnuDisplayNonfiction.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.mnuDisplayNonfiction.Size = New System.Drawing.Size(180, 22)
        Me.mnuDisplayNonfiction.Text = "Nonfiction"
        '
        'mnuValues
        '
        Me.mnuValues.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuValuesAll, Me.mnuValuesFiction, Me.mnuValuesNonfiction})
        Me.mnuValues.Name = "mnuValues"
        Me.mnuValues.Size = New System.Drawing.Size(52, 20)
        Me.mnuValues.Text = "Values"
        '
        'mnuValuesAll
        '
        Me.mnuValuesAll.Name = "mnuValuesAll"
        Me.mnuValuesAll.Size = New System.Drawing.Size(131, 22)
        Me.mnuValuesAll.Text = "All"
        '
        'mnuValuesFiction
        '
        Me.mnuValuesFiction.Name = "mnuValuesFiction"
        Me.mnuValuesFiction.Size = New System.Drawing.Size(131, 22)
        Me.mnuValuesFiction.Text = "Fiction"
        '
        'mnuValuesNonfiction
        '
        Me.mnuValuesNonfiction.Name = "mnuValuesNonfiction"
        Me.mnuValuesNonfiction.Size = New System.Drawing.Size(131, 22)
        Me.mnuValuesNonfiction.Text = "Nonfiction"
        '
        'frmBooks
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(332, 227)
        Me.Controls.Add(Me.lstBooks)
        Me.Controls.Add(Me.MainMenu1)
        Me.MainMenuStrip = Me.MainMenu1
        Me.Name = "frmBooks"
        Me.Text = "Book Inventory"
        Me.MainMenu1.ResumeLayout(False)
        Me.MainMenu1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstBooks As ListBox
    Friend WithEvents MainMenu1 As MenuStrip
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents mnuFileSave As ToolStripMenuItem
    Friend WithEvents mnuFileExit As ToolStripMenuItem
    Friend WithEvents mnuBook As ToolStripMenuItem
    Friend WithEvents mnuBookAdd As ToolStripMenuItem
    Friend WithEvents mnuBookDelete As ToolStripMenuItem
    Friend WithEvents mnuBookUpdate As ToolStripMenuItem
    Friend WithEvents mnuDisplay As ToolStripMenuItem
    Friend WithEvents mnuDisplayAll As ToolStripMenuItem
    Friend WithEvents mnuDisplayFiction As ToolStripMenuItem
    Friend WithEvents mnuDisplayNonfiction As ToolStripMenuItem
    Friend WithEvents mnuValues As ToolStripMenuItem
    Friend WithEvents mnuValuesAll As ToolStripMenuItem
    Friend WithEvents mnuValuesFiction As ToolStripMenuItem
    Friend WithEvents mnuValuesNonfiction As ToolStripMenuItem
End Class
