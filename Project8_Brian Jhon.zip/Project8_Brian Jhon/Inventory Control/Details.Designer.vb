﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.txtAuthor = New System.Windows.Forms.TextBox()
        Me.lblAuthor = New System.Windows.Forms.Label()
        Me.txtStock = New System.Windows.Forms.TextBox()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.lblStock = New System.Windows.Forms.Label()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.grpCategory = New System.Windows.Forms.GroupBox()
        Me.radNonfiction = New System.Windows.Forms.RadioButton()
        Me.radFiction = New System.Windows.Forms.RadioButton()
        Me.btnRecord = New System.Windows.Forms.Button()
        Me.grpCategory.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtTitle
        '
        Me.txtTitle.Location = New System.Drawing.Point(71, 21)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(202, 20)
        Me.txtTitle.TabIndex = 0
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Location = New System.Drawing.Point(34, 24)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(30, 13)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "Title:"
        '
        'txtAuthor
        '
        Me.txtAuthor.Location = New System.Drawing.Point(71, 55)
        Me.txtAuthor.Name = "txtAuthor"
        Me.txtAuthor.Size = New System.Drawing.Size(202, 20)
        Me.txtAuthor.TabIndex = 2
        '
        'lblAuthor
        '
        Me.lblAuthor.AutoSize = True
        Me.lblAuthor.Location = New System.Drawing.Point(23, 58)
        Me.lblAuthor.Name = "lblAuthor"
        Me.lblAuthor.Size = New System.Drawing.Size(41, 13)
        Me.lblAuthor.TabIndex = 3
        Me.lblAuthor.Text = "Author:"
        '
        'txtStock
        '
        Me.txtStock.Location = New System.Drawing.Point(70, 99)
        Me.txtStock.Name = "txtStock"
        Me.txtStock.Size = New System.Drawing.Size(53, 20)
        Me.txtStock.TabIndex = 4
        '
        'txtPrice
        '
        Me.txtPrice.Location = New System.Drawing.Point(205, 99)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(68, 20)
        Me.txtPrice.TabIndex = 5
        '
        'lblStock
        '
        Me.lblStock.AutoSize = True
        Me.lblStock.Location = New System.Drawing.Point(26, 102)
        Me.lblStock.Name = "lblStock"
        Me.lblStock.Size = New System.Drawing.Size(38, 13)
        Me.lblStock.TabIndex = 6
        Me.lblStock.Text = "Stock:"
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.Location = New System.Drawing.Point(165, 102)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(34, 13)
        Me.lblPrice.TabIndex = 7
        Me.lblPrice.Text = "Price:"
        '
        'grpCategory
        '
        Me.grpCategory.Controls.Add(Me.radNonfiction)
        Me.grpCategory.Controls.Add(Me.radFiction)
        Me.grpCategory.Location = New System.Drawing.Point(29, 143)
        Me.grpCategory.Name = "grpCategory"
        Me.grpCategory.Size = New System.Drawing.Size(244, 66)
        Me.grpCategory.TabIndex = 8
        Me.grpCategory.TabStop = False
        Me.grpCategory.Text = "Category"
        '
        'radNonfiction
        '
        Me.radNonfiction.AutoSize = True
        Me.radNonfiction.Location = New System.Drawing.Point(117, 30)
        Me.radNonfiction.Name = "radNonfiction"
        Me.radNonfiction.Size = New System.Drawing.Size(73, 17)
        Me.radNonfiction.TabIndex = 1
        Me.radNonfiction.Text = "Nonfiction"
        Me.radNonfiction.UseVisualStyleBackColor = True
        '
        'radFiction
        '
        Me.radFiction.AutoSize = True
        Me.radFiction.Checked = True
        Me.radFiction.Location = New System.Drawing.Point(6, 30)
        Me.radFiction.Name = "radFiction"
        Me.radFiction.Size = New System.Drawing.Size(56, 17)
        Me.radFiction.TabIndex = 0
        Me.radFiction.TabStop = True
        Me.radFiction.Text = "Fiction"
        Me.radFiction.UseVisualStyleBackColor = True
        '
        'btnRecord
        '
        Me.btnRecord.Location = New System.Drawing.Point(26, 215)
        Me.btnRecord.Name = "btnRecord"
        Me.btnRecord.Size = New System.Drawing.Size(247, 27)
        Me.btnRecord.TabIndex = 9
        Me.btnRecord.Text = "Record Details"
        Me.btnRecord.UseVisualStyleBackColor = True
        '
        'frmDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(295, 258)
        Me.Controls.Add(Me.btnRecord)
        Me.Controls.Add(Me.grpCategory)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.lblStock)
        Me.Controls.Add(Me.txtPrice)
        Me.Controls.Add(Me.txtStock)
        Me.Controls.Add(Me.lblAuthor)
        Me.Controls.Add(Me.txtAuthor)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.txtTitle)
        Me.Name = "frmDetails"
        Me.Text = "Details"
        Me.grpCategory.ResumeLayout(False)
        Me.grpCategory.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtTitle As TextBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents txtAuthor As TextBox
    Friend WithEvents lblAuthor As Label
    Friend WithEvents txtStock As TextBox
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents lblStock As Label
    Friend WithEvents lblPrice As Label
    Friend WithEvents grpCategory As GroupBox
    Friend WithEvents radNonfiction As RadioButton
    Friend WithEvents radFiction As RadioButton
    Friend WithEvents btnRecord As Button
End Class
